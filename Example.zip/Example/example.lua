vanilla_model.ALL:visible(false)
nameplate.ENTITY:visible(false)
local animatedText = require("animatedText")

local myJson = {
	{text = 'This is line 1. :notepad++::java:\nThis is line 2.'},
	{text = avatar:getBadges(), font = "figura:badges", color = avatar:getColor()}
}

animatedText.new("myTask", models.model.root.Head, vec(0,20,0), vec(.4,.4,0), "Billboard", myJson)
function events.render(delta, context)
	if context ~= "FIRST_PERSON" and context ~= "RENDER" then return end
	for i, v in pairs(animatedText.getTask("myTask").textTasks) do
		animatedText.transform("myTask", vec(0, math.sin((world:getTime() + delta) / 8 + i) * .25, 0), nil, nil, v)
	end
end