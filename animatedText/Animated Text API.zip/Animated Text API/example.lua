vanilla_model.PLAYER:visible(false)

--require the script for use
local animatedText = require("animatedText") 

--create text, can be a regular string if you wish
local myJson = { 
		{text = 'now playing: lorem ipsum ™:notepad++::java:', italic = true},
		{text = avatar:getBadges(), font = "figura:badges", color = avatar:getColor()}
	}

--add text as a new set of tasks
animatedText.new("myTask", models.model.root.Head, vec(0, 15, 0), vec(.5, .5, 1), "BILLBOARD", myJson) 
for _, v in pairs(animatedText.getTask("myTask").textTasks) do v.task:outline(true) end

local tickTime = 0 
function events.tick() tickTime = tickTime + 1 end

--in this example, we use a formula to offset the sine of each character based on its index (i) and amplify its motion by .5
function events.render(delta, context)
	if context ~= "FIRST_PERSON" and context ~= "RENDER" then return end
	for i, v in pairs(animatedText.getTask("myTask").textTasks) do
		animatedText.transform("myTask", vec(0, math.sin((tickTime + delta) / 8 + i) * .5, 0), nil, nil, v)
	end
end